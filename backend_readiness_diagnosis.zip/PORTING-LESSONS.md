# PORTING-LESSONS: what actually breaks when moving an inference engine to another GPU

Derived from a full CUDA→HIP port of a ternary-quantised LLM engine to RDNA4
(gfx1201). Every rule below is tied to a failure that was observed and measured,
not to a theory. Apply them to any engine of the same class (ninfer, deepinfer,
llama.cpp derivatives, vLLM-like servers, custom quantised GEMV stacks).

**The rules are stated in vendor-neutral terms.** Any execution model with an
asynchronous host-side submission queue and a SIMD device obeys them: the
platform name, instruction or file extension that appears below is the *evidence*,
never the subject. The Terminology map translates between the vocabularies.

The short version:

> **Plan from probes, not from memory. Compile the instruction. Read the
> disassembly. Run the model. Gate the build on invariants.**

---

## Terminology

The rules below are stated in API-neutral terms. Where a platform name is needed
for evidence, it appears in parentheses. Any execution model with an
asynchronous host-side submission queue obeys the same rules.

| concept here | CUDA | HIP / ROCm | Vulkan / DirectX | Metal | SYCL / oneAPI |
|---|---|---|---|---|---|
| work queue | stream | stream | queue | command queue | queue |
| captured commands | graph | graph | secondary command buffer | indirect command buffer | command graph |
| execution batch | block | workgroup | workgroup | threadgroup | work-group |
| SIMD unit | warp (32) | wavefront (32/64) | subgroup | SIMD group | sub-group |
| lane | thread | lane | invocation | thread | work-item |
| fast scratch | shared memory (SMEM) | LDS | groupshared | threadgroup memory | local accessor |
| timestamp | cudaEvent | hipEvent | timestamp query | encoder sample | event |
| kernel artifact | cubin / fatbin | hsaco / code object | SPIR-V module | metallib | SPIR-V / binary |
| compute unit | SM | CU | CU / EU | GPU core | Xe-core / EU |
| register count | registers/thread | VGPR / SGPR | registers | registers | registers |

"Host", "device", "kernel" and "launch" are used throughout because every one of
these APIs shares the same model: the host queues work asynchronously and the
device executes it later.

---

## 1. Hard rules (gates that must exist before the first edit)

| # | Gate | Why it exists |
|---|---|---|
| G0 | `build_function_reference` before anything else | the pre-port inventory turns "where do I start" into a work list: every runtime API, PTX instruction, intrinsic and feature used, its replacement, and whether that is auto / partial / manual / no-equivalent |
| G1 | `probe_isa` every instruction the port depends on, one candidate per TU | a whole port was designed around `v_dot4_i32_i8`; the gfx12 backend *crashes* on it rather than rejecting it at the assembler |
| G2 | `scan_residual_asm` must return zero before compiling | foreign mnemonics survived four "fix" passes because each regex silently no-op'd |
| G3 | delete the output artifact before every build | a stale `.hsaco` made a probe report kernels the current source could not produce |
| G4 | assert the exported symbol inventory matches the expected kernel list | "it compiled" and "the runtime can call it" are different claims |
| G5 | run the model and check the text, not just the exit code | compiling and producing coherent output are different claims |
| G6 | `postport_recheck` before any performance claim, and again after every change | a port can be correct, build clean, and still spend 92% of its time in dispatch overhead; the recheck is what turns "it feels slow" into a number |

If a gate cannot be expressed, the port is not ready to start.

---

## 2. ISA verification protocol

1. **Compile the candidate on the real target.** Capability tables, vendor docs
   and model memory are all unreliable. One compile is decisive.
2. **One candidate per translation unit.** Probing several in one file means the
   first error masks the rest. This cost a full round trip.
3. **Read the disassembly, not just the exit code.** Measured on gfx1201:

   | source | compiler result | emitted |
   |---|---|---|
   | `asm("v_dot4_i32_i8 …")` | backend crash | none (gfx9-only encoding) |
   | `amd_mixed_dot(char4,…)` | ok | `v_dot4_i32_iu8` ✅ |
   | `__builtin_amdgcn_udot4(…)` | ok | `v_dot4_u32_u8` ✅ |
   | scalar expansion | ok | no dot instruction |

   The *mnemonic* is not the capability. Two of these are the same hardware op
   under different spellings; one does not exist.
4. **Confirm the default empirically, and verify the artifact rather than the
   flag.** `-mwavefrontsize32` was rejected outright by the toolchain
   ("unknown argument") and the default was already 32 lanes: `__ballot(1)`
   returns `0x00000000ffffffff` and the code object records
   `.wavefront_size: 32`. Two separate lessons in one measurement. A flag that
   a document describes may not exist in your compiler, and a flag that *is*
   accepted may be silently ignored. Read the emitted object, or probe the
   hardware, before believing either. (A spelling this toolchain accepts is
   `-Xclang -target-feature -Xclang +wavefrontsize32`.)
5. **Treat every "portable intrinsic" as unproven until disassembled.** A builtin
   that compiles may lower to a scalar loop.

Probe recipe:

```python
from isa_tools import probe_many
probe_many("gfx1201", [
    {"name": "raw v_dot4",  "stmt": 'asm("v_dot4_i32_i8 %0,%1,%2,%0;" : "+r"(acc) : "r"(a),"r"(b));'},
    {"name": "hip helper",  "stmt": "acc = amd_mixed_dot(ca, cb, acc, false);"},
], backend="hip")
```

---

## 3. Source transformation: the six ways a rewrite silently fails

1. **Literal mismatch.** `cp.async.ca_shared.global` in the pattern vs
   `cp.async.ca.shared.global` in the source. Zero substitutions, no error.
2. **Prefix mismatch.** Pattern expects `asm(`; source says `asm volatile(`.
3. **Terminator mismatch.** Pattern expects `";`; a multi-line macro ends
   `};"\` (backslash continuation). The regex never matches.
4. **Cross-line matching.** `re.DOTALL` on a line-oriented pattern makes `.*?`
   consume hundreds of lines up to an unrelated `";`, deleting real code.
5. **Whole-line replacement.** `tc_commit(){ asm(...); }` on one line is
   destroyed when a sweep replaces the entire line instead of the asm statement.
6. **Ordering.** Rewriting asm constraints (`"l"`→`"r"`) *before* the pattern
   that keys on `"l"` guarantees the later pattern misses.

Two structural traps that are worse than any of the above:

- **`__launch_bounds__(N)`** is the first `(` after the qualifier, so any naive
  signature scan names the function `__launch_bounds__` and the kernel vanishes
  from the inventory. Blank it before scanning. This bit twice, once in the
  hipifier, once in the porting-map extractor.
- **ISA constructs hide in macros.** `#define TC_MMA … mma.sync …` means a
  body-only scan reports a clean bill of health on code built entirely from an
  unsupported instruction. Attribute macro constructs to their callers.

**Do not hand-write instruction mnemonics.** Use the vendor's helper
(`amd_mixed_dot`, `__dp4a`, `sycl::…`) so the compiler chooses the encoding.

**Decide the output extension before rewriting anything.** A port is not
"translate every file": some files are copied verbatim, some change extension
and must be rewritten, and a few change language entirely. For example:

| source | → HIP | → Vulkan | action |
|---|---|---|---|
| `.cu` | `.hip` | `.comp` | rewrite |
| `.cl` (OpenCL) | `.cpp` | `.comp` | rewrite |
| `.comp` (GLSL) | `.cpp` | `.comp` | **copy** when targeting Vulkan |
| `.hlsl` | `.cpp` | `.comp` | rewrite |
| `.metal` | `.cpp` | `.comp` | rewrite |

Getting this wrong produces a tree that builds nothing, or silently drops the
files that needed real work. Generate the plan (`build_porting_map` → `file_plan`)
and review the rewrite/copy split before writing code.

---

## 4. Runtime and dependency layer

Inference engines rarely isolate the GPU behind a clean seam. Expect all of:

| dependency | what it looks like | handling |
|---|---|---|
| vendor array/tensor lib | `import cupy`, `torch.cuda` | replace the **interface**, not just kernels (a shim) |
| raw driver calls | `ctypes.CDLL("libcuda.so.1")`, `cuLaunchKernel`, `cuFuncSetSharedMemConfig` | intercept; `cuLaunchKernel` argument shape matches `hipModuleLaunchKernel` |
| CUDA graphs | `cuGraphCreate` … used for decode replay | `hipGraph*` exists; otherwise return failure so the engine falls back |
| runtime-generated code | engine concatenates sources and **generates wrappers from kernel text at load time** | replicate the generation; otherwise `d_k_*` symbols are "missing" when they were never emitted |
| build-time extension | `torch.utils.cpp_extension`, `setup.py` with nvcc | hipcc + `HIP_PLATFORM=amd`, or port the source |
| graphs/streams/events | per-token sync, double buffering | map to HIP equivalents; measure the sync cost |

**Shim conformance is behavioural, not nominal.** Broken in one port:

- device name returned `str`, engine called `.decode()` → returns **bytes**
- `arr[i]` returned a host scalar; engine passes it to a kernel → returns a
  **0-d device view**
- strided view `.copy()` did a flat `memcpy` → copy **per contiguous run**
- `kernelParams[i]` was the device pointer instead of a pointer **to** the value
  → access violation reading a device address on the host
- missing `Device.compute_capability`, `pool.free_bytes()` → attribute cascade

Checklist: enumerate every vendor-stack attribute the engine touches
(`grep -o 'cp\.[A-Za-z_.]*'`) and confirm each one exists with the right type.

---

## 5. Correctness protocol

1. Unit-test the smallest kernel you can (vec-add, a 4-element dot) before
   trusting the model.
2. Run the model. Coherent output on several unrelated prompts (factual, math,
   code) is the minimum bar.
3. Prefer a reference oracle: the upstream vendor fork, a CPU implementation, or
   llama.cpp. For Bonsai-style models the vendor publishes a tested setup. Use
   it to confirm formats and expected quality.
4. **Grade fidelity explicitly.** A matrix instruction reconstructed element-wise
   is *approximate*, not equivalent. Gate it off by default
   (`supported() == False`) instead of silently serving wrong logits, and let the
   numerically faithful path be canonical.
5. Verify the *format* too: the same tensor id can mean different layouts across
   runtime generations (e.g. legacy vs official group-size). Loading successfully
   does not mean loading correctly.

---

## 6. Performance method

Never quote a per-kernel number collected with a sync after every launch. Any
platform whose driver batches submissions (Windows/WDDM is one) inflates it by an
order of magnitude. Separate:

```
wall = host-launch + queue-wait + device-exec + sync
```

**Correction:** an earlier version of this section reported "25 ms device" for
this token. That figure came from the sync-per-launch instrument and was wrong.
Re-measured properly: **device 1.94 ms, host 3.3 ms, wall 5.34 ms**. The
per-launch conclusion held; the device number was inflated ~13x, and it hid a
second, real problem, which was the device running at 39% of achievable bandwidth. A
wrong measurement that survives into documentation is worse than no measurement.

### 6.1 Calibrate the instrument before you believe the number

Four different ways of timing the *same* kernel gave answers spanning three
orders of magnitude:

| instrument | what it actually reports |
|---|---|
| one timestamp pair around a whole phase | the **host's submission span**. When the host is the bottleneck the device is idle and the interval still equals wall time, so it looks like "device = wall" |
| a timestamp pair around every operation | the **instrumentation floor**, which is per operation, not per kernel: ~19 us here, so 346 operations invent ~6.7 ms of device time out of nothing |
| launch followed by an immediate device sync | the **driver round trip** (submission, signal, wake-up), not the kernel |
| **burst replay, host-subtracted** | the kernel. Queue the same launch 200+ times with nothing in between so the queue stays deep, then `kernel = wall - host_queue_time` |

The numbers in this table are one measured example (a 346-launch token on a
discrete GPU under Windows); the ordering of the four instruments is what
transfers.

- **Validate the timer against a known workload first.** A streaming read of a
  known size gives a measurable bandwidth; if the timer disagrees with it, the
  timer is wrong. (Here: 512 MB in 871 us = 616 GB/s, matching wall clock.)
- **A timestamp pair isolates a kernel only if nothing else is queued behind
  it.** Otherwise it measures queue wait as well.
- **Prefer one big interval over many small ones** for totals: ten tokens inside a
  single pair is honest; ten tokens each with their own pair is ten times the floor,
  and the floor is not small.
- **Do not assume the queue drains in order with your host code.** The host can
  finish submitting long before the device finishes executing, which is what makes
  the first row of the table above so misleading.
- **Own every queue, or sync the device.** If part of the workload is submitted to the
  default queue (the null stream in CUDA/HIP, the default command queue elsewhere) while
  the measurement synchronises only a private one, the timing returns before the work has
  finished and the path looks several times faster than it is. Seen here: an engine
  submitting an entire token plan on the null stream while the shim synchronised its own,
  so a batched path was measured at 2.3 ms/token, which implied 2.3 TB/s of weight
  traffic and is therefore impossible. Validate by comparing against a device-wide sync.
- **Count the work from the artifact, not from the source.** A microbenchmark's arithmetic
  must come from the instructions actually emitted, because a loop body commonly holds more
  than one instance of the operation of interest: a four-fold miscount here made a figure
  wrong by 4x, and the error survived because the number looked plausible.
- **Interleave the variants inside one thermal state.** Sweeping variants one after another
  lets the clock drift between them, and the same kernel then read 94 in one sweep and 170
  in another. Running them round-robin and taking the best per round made the figures
  reproducible to about 1 percent. If a number moves when you re-run it, it is not a
  measurement yet, and do not build a plan on it.
- **Check a throughput figure against the issue bound before believing it.** Divide the
  measured operations per second by the unit count and the clock to get operations per
  cycle per unit. If that comes out above what the hardware can issue, the number is wrong;
  if it comes out at a clean fraction like a quarter, the kernel is probably at a real
  limit. Here the measured 0.22 matrix ops per unit per cycle was the tell that a widely
  quoted one-per-cycle figure was about 4.5x too high.
- **Score an ablation on the quantity, not on a downstream coin flip.** Free-running greedy
  decoding is chaotic: any perturbation changes the output, so "the first token differs"
  says nothing about whether the perturbation mattered. Score the change at the point of
  interest instead, as the magnitude of the difference in the next-token logits and the
  total variation between the two distributions. Here a window that shrank the context to
  a quarter produced a large logit shift but left the argmax intact, while a window of
  eight tokens broke it, and only the magnitude showed that ordering.
- **Always include the degenerate setting that should be a no-op, and require exactly
  zero.** A window equal to the prompt length must reproduce the baseline bit for bit.
  It is free, it validates the whole harness, and here it was the measurement that proved
  the fix had landed.
- **Verify the code path that runs, not the one you edited.** A file can define the same
  method twice and bind the last definition; an edit to the earlier one is dead code and
  the measurement will silently reproduce the old behaviour. Print the source line of the
  function that is actually reachable before trusting a change to it.

### 6.2 Decompose, then ask which side the wall is on

```
wall = host-active (launch calls + engine Python) + exposed device + idle gaps
```

The decisive question is **does the host finish submitting before the device
finishes executing?**

- If yes, the device idles through the token and the wall is **host-shaped**:
  launch count, per-launch cost and engine Python are the targets.
- If no, the wall is **device-shaped**: go into the kernels.

This distinction flipped the whole diagnosis of one port. The host took 3.48 ms
to submit a token whose device work was 1.94 ms. The device had already finished
while the host was still submitting, so device optimisation alone could not have
helped.

### 6.3 Invariant: the parts cannot exceed the whole

If the sum of measured device time exceeds wall time, the instrument is
inflating. Stop and fix the measurement. This one check catches the floor,
double counting, and timestamps taken on a different queue than the work.

### 6.4 Findings that generalise

- **A workload is launch-shaped when the model is small relative to the GPU.**
  346 launches x ~10 us of host cost was 3.3 ms of a 5.3 ms token. Compute
  `launches x per-launch cost` and compare with device time; if it is larger,
  fusion or capture is the win, not better arithmetic. A design that was fine on
  a 1-SM, 28 GB/s card becomes launch-bound on a 32-CU, 616 GB/s one.
- **Batching is the strongest cure for launch overhead** where the workload
  allows it: the same weights on the same card, as one GEMM over 256 tokens
  instead of one GEMV per token, cost **6.1x less per token**. Autoregressive
  decode cannot batch across tokens, which is exactly why its per-launch tax has
  to be removed structurally.
- **Rank by cumulative cost, and re-rank after every change.** The bottleneck
  moves. After launch reduction the device became visible again, and the profile
  changed from host-bound to device-at-39%-of-achievable-bandwidth.
- **Size the grid to the work, not to the CU count.** Sweep `gx`/`gy`; a tensor
  with `NG/32 = 4` useful blocks does not benefit from 72.
- **Check the roofline per tensor class, against measured bandwidth.** Small
  tensors are latency-bound, large ones can saturate; different problems.
- **Confirm the instruction helps.** A hardware dot product was equivalent to
  scalar for a workload whose hot loop used a lookup table instead.

### 6.5 Accept a change only on reproducible, bit-exact evidence

- **Fast can mean wrong.** A block-size change measured 1.6x faster and produced
  all-zero tokens. Assert numerics bit-for-bit against a reference *before*
  accepting a speedup. Timing without verification is not a result.
- **Check that the comparison harness proves anything.** A differential test that
  "passed" was comparing NaN to NaN, because the reference itself was invalid (synthetic
  inputs the kernel never sees). Print the reference's magnitude, finiteness and
  a checksum; a degenerate reference makes every candidate look equal.
- **Enough samples, a median, and interleaved arms.** 24-token samples varied by
  +-8%, larger than the effects being chased; 100 tokens cut that to ~1%. Arms
  run back to back also drift with clock and thermal state, so run A, B, A, B. An
  improvement that does not reproduce is not an improvement, and retracting one
  is a normal outcome.
- **Keep the known-good configuration:** revert first, re-measure, then change
  one variable.

- **Launch count times fixed cost dominates** for small tensors. 1 to 3 MB GEMVs sat at
  20 to 70 GB/s while the 127 MB head reached 462 GB/s. Optimise by **fusion and
  fewer launches**, not by better math inside a 40 µs kernel.
- **Size the grid to the work, not to the CU count.** Sweep `gx`/`gy`; a tensor
  with `NG/32 = 4` useful blocks does not benefit from 72.
- **Check the roofline per tensor class.** Small tensors are latency-bound; large
  ones can saturate. Treat them as different optimisation problems.
- **Verify the instruction actually helps.** The hardware dot4 was equivalent to
  scalar for this workload because the hot loop used a lookup table, not dp4a.

---

## 7. Verify the artifact, not the flag

The compiler is not the oracle. **The emitted code object is.**

1. **Know your container.** `hipcc`/`nvcc` write a *bundle* (clang offload
   bundle or fatbinary), not a bare ELF, so `objdump`/`nm` reject it with "not
   recognized as a valid object file", and a bundle can hold several
   architectures. Slicing from the first ELF magic analyses whichever payload
   comes first, i.e. possibly an architecture that was never targeted. Parse the
   container and select by triple (`unwrap_code_object(path, arch=...)`).
2. **Read the metadata, do not infer it.** A kernel artifact states SIMD width,
   register counts (VGPR/SGPR, or plain registers), spill counts and segment
   sizes (shared/scratch memory per block). `code_object_report` extracts them
   per kernel and computes how many blocks that scratch memory allows to be
   resident on a compute unit.
3. **Distinguish "flag rejected" from "source broken".** A probe of six compiler
   flags "proved" all six were rejected; in fact the test source did not compile
   and every candidate failed for an unrelated reason. When a probe fails, print
   the whole error and test the null hypothesis (compile with no flag at all).
4. **Defaults are not what you assume.** The same probe showed one flag was
   unnecessary because the default was already the desired behaviour, while
   another toolchain defaults the other way. Measure the default.
5. **Multi-arch bundles mean symbol inventories can lie.** A module that builds
   and exports `k_g4` may export it for the wrong target. Delete the artifact
   before every build (G3) and confirm the payload triple.

### 7.1 Residency audit: port the reason, not the code

The highest-value reading in one port came from a single field:

| field (generic name) | value | consequence |
|---|---|---|
| shared memory per block (`group_segment_fixed_size`, `smem`) | 41 472 B | against 64 KiB usable per compute unit: **one block resident per CU** |
| bytes fetched from global memory | 96 B per iteration | the kernel is not streaming |
| shared-memory loads + vector bit-manipulation ops | 64 + 64 per iteration | issue slots are spent **decoding**, not moving data |
| SIMD width (`wavefront_size`, warp size) | 32 | (the assumed problem, already correct) |

That kernel was a ternary decode loop written for a GPU with **no integer dot
hardware** (a low-end Kepler part): hoisting lookup tables into shared memory was
the only way to decode.
On the new target the tables pin occupancy at one block per CU and burn the issue
slots. The design's *reason* had disappeared, and nothing in the port pointed at
it, because the code still compiled and still produced correct output.

**Rule: when a kernel hoists data into a scarce resource (shared memory,
registers, a texture, constant memory), ask what scarcity it was written for. If
the new target does not have that scarcity - or has the instruction that made the
trick unnecessary - the structure is now a tax, not an optimisation.**

---

### 7.2 Probe the construct in your toolchain's spelling, then unwrap the container

Two failure modes, both hit inside one investigation of one instruction family:

- **The instruction existed; the spelling was the previous generation's.** RDNA4 has fp8,
  bf16, f16, int8 and int4 WMMA, but gfx12 names them differently
  (`__builtin_amdgcn_wmma_i32_16x16x16_iu4_w32_gfx12`) and changes the operand shapes
  (scalar `int` operands for iu4 on gfx12, `V2i` vectors on gfx11). A probe built from
  gfx11 spellings reported the whole family as "not encodable" while the builtins were
  listed in the SDK's own table at
  `lib/llvm/include/clang/Basic/BuiltinsAMDGPU.inc`. Read the compiler's table and the
  target's per-instruction pages before concluding that an instruction is absent.
- **Reading the artifact without unwrapping it hides everything.** `.hsaco` and `.cubin`
  are clang offload bundles; disassembling the bundle reports no instructions at all,
  which is easy to mistake for "the compiler emitted nothing". Extract the per-arch
  payload first.

And a third rule that generalises further: **compiling is not emitting, and emitting is not
emitting efficiently.** Count the instructions *around* the one that matters, because
twenty supporting instructions per matrix op caps the result at a fraction of the rated
throughput whatever the operand width. Related: a single dependent accumulator chain
measures the instruction's latency, not its throughput.

---

## 8. Capture and replay: the semantics that bite

Recording a command sequence once and replaying it as a single unit (CUDA/HIP
graphs, secondary command buffers, command graphs) is the cheapest large win for
a launch-shaped engine: measured 186 -> 250-268 tok/s over 18 layers with no
numerical change. It is also easy to get subtly, silently wrong.

1. **Audit the captured region for capture-illegal operations.** Allocations and
   synchronising copies are illegal. Make transfers stream-ordered first (async
   copies are legal, sync ones are not) and look for hidden allocation in hot
   paths (`.copy()` on a view is a common one).
2. **A captured region bakes in host-side bookkeeping.** Anything the host would
   have done during the recorded calls, such as swapping buffers, resetting a flag or advancing a
   counter, does *not* happen on replay, and the next kernel may
   branch on it. Record the host state after the recording pass and re-apply it,
   or the replay silently uses stale state.
3. **A capture is only valid for the state and context it was recorded in.** It
   bakes in the buffers, strides and arguments that were live at record time.
   In one engine a double-buffered activation stream meant the buffer at a given
   layer depended on how many buffers had already been swapped, and that count
   differed between two entry paths (one performed an extra normalisation per
   step). Replaying a capture recorded on the other path read the wrong buffer.
   Key captures by a signature of the state they assume, and record a second one
   when the signature changes. The same applies to shapes, dtypes, and batch
   dimensions: a capture is not a function.
4. **A failed capture must re-run the work.** During capture kernels are
   *recorded*, not executed. Every failure path, whether capture was refused or end-capture or instantiate
   failed, has to fall back to running the region for real,
   and should blacklist the tag so it is not retried on every token.
5. **Verify capture against the un-captured path, including phase transitions.**
   Testing one phase in isolation passed while the transition from a batched
   phase into a token-at-a-time phase produced garbage. Compare exact outputs
   across the *transitions* between heterogeneous code paths, not only within one.
   This is also where a wrong buffer or a stale flag shows up first.

---

## 9. Measured numbers beat datasheet numbers

Every roofline in a port is divided by an assumed bandwidth and multiplied by an
assumed resource size. Both are usually wrong, and usually in the direction that
hides the real gap. One measured example, from a single card:

| quantity | reference value | measured value | consequence of the gap |
|---|---|---|---|
| streaming bandwidth | 1152 GB/s | **616 GB/s** | a "39% of peak" kernel is really 73% of what the machine can do: the target was 2x too optimistic |
| cache-resident bandwidth | - | **~1424 GB/s** | working sets that fit in cache are worth structuring for |
| scratch memory per compute unit | 128 KiB (in the table) | **64 KiB usable** | residency math is off by 2x |
| number of compute units | 72 (in the table) | **32 reported by the runtime** | the runtime property counted *workgroup processors*, not compute units (32 WGP = 64 CU) |

Rules:

- **Store the measured value with its provenance.** "1152 GB/s" is a spec;
  "616 GB/s measured by a 512 MB streaming read on this card" is a number you can
  divide by. Mark which is which in any data file.
- **Beware unit ambiguity in runtime properties.** A property named
  "multiprocessor count" or "compute unit count" may return execution batches,
  half-compute-units, or something else entirely. Confirm against the physical
  spec before using it to size a grid - a factor-of-two error here silently
  halves occupancy or doubles the grid.
- **Calibrate both ends of the memory hierarchy** if the workload has two
  regimes: streaming (DRAM) and cache-resident. They differ by 2x or more.

---

## 10. Engine-class checklist (ninfer / deepinfer / llama.cpp-derived)

Before writing any kernel, answer these. Each "no" is a scoping risk.

**A. What already works on the target?**
- Does the vendor publish a tested HIP/ROCm build of a comparable engine? Use it
  as the reference oracle for numerics and formats.
- Is ROCm PyTorch already installed? If the engine is PyTorch-based, much of the
  port may be "install the right wheel", not "write kernels".
- Does the engine already have a Triton or ONNX path? Those may need no port at
  all.

**B. What is actually custom?**
- Identify the *quantised* kernels: int4/int8/fp8 GEMV, dequant, attention,
  KV-cache layout. These are the real work; everything else is plumbing.
- Map each custom kernel to a construct family and grade it (see §2/§5).

**C. What runtime machinery must be replaced?**
- Allocator / memory pool, streams, events, graphs, peer copies.
- Build system: extension compiled at install time? Cross-compiling for gfx1201?
- Multi-GPU/NCCL → RCCL. Scope single-GPU first.

**D. What are the named library dependencies?**
- `cuBLAS/cuBLASLt` → hipBLASLt; `cuDNN` → MIOpen/CK; `CUB/Thrust` →
  hipCUB/rocThrust; `FlashAttention` → CK or a Triton/torch SDPA fallback;
  `NCCL` → RCCL. Confirm each has a drop-in for the *specific* call used, not
  just "exists on AMD".

**E. What data types are required?**
- fp8 / bf16 / fp16 / int8 support differs per arch. Probe, don't assume:
  gfx12 rejected one packed-fp16 instruction outright while accepting its
  two-instruction replacement.

**F. What is the numerical contract?**
- Which kernels must be bit-exact and which may be approximate? Write it down
  before touching either. Attention softmax and output projection tolerate far
  less than an activation.

---

## 11. Process discipline

1. **One source of truth for generated files.** Four overlapping "fix" scripts
   caused two silent regressions. Keep one pipeline; if a second pass is needed,
   make it report counts of what it changed.
2. **Probe before planning.** A 20-second compile would have saved most of the
   first day.
3. **Record the measurement with the change.** "Faster" without a number is not
   a result.
4. **Never let a script mutate files without a summary.** Diff, count, or hash.
5. **Re-inspect after any edit that rewrites large regions.** A truncation to
   3 lines is invisible until the next build.

---

## 12. Batch size decides the engine; measure the binding resource per batch

A quantised matmul has two candidate engines: a scalar kernel over the densest packing,
or a matrix-core kernel that needs wider operands. Which one wins is decided by the
**batch size**, not by the instruction set. Measured on one ternary model (2-bit
weights, 25.6 G of them) on one card with a 634 GB/s measured ceiling:

| batch | binding resource | measured |
|---|---|---|
| T = 1 (decode) | **bytes**: 76% of the bandwidth ceiling | 481 GB/s, 14.2 ms/token |
| T = 256 (prefill) | **compute**: 5.6 TOPS against ~20 scalar TFLOPS, memory at **0.7%** | weights read once, 4.6 GB/s, 220 tokens/s |

- **At T = 1, any wider operand is a loss.** Ternary packs to 2 bits. The narrowest
  matrix-core operand is 4 bits (`iu4`), then 8 (int8/fp8) and 16 (fp16/bf16). Doubling
  the weight bytes cannot be repaid by removing decode work when the kernel is already
  at 76% of the achievable bandwidth. This holds for every packed-dot instruction and
  every matrix-core spelling alike (`dp4a`/`amd_mixed_dot`, `v_dot8_i32_iu4`, WMMA,
  MFMA, `mma.sync`).
- **At large T the matrix core wins**, because the weight read is amortised over the
  whole batch: the same 2x operand expansion is free when the memory bus sits at 0.7%
  and the compute is the wall.
- **So do not choose the engine once.** Measure bytes against MACs at the batch sizes
  the engine actually runs, and expect the answer to flip somewhere around the point
  where `batch x MACs / compute_rate` overtakes `bytes / bandwidth`.
- **Corollary: batch and decode paths drift apart.** Here the *default* chunked GEMM on
  the prefill path was a Kepler-era scalar core (sm_30, 63 registers, `kep3_core`) while
  the decode kernel had been retuned, so the "efficient" path was the opposite of the
  batched one at 36x per byte. Inventory the **default per path**, not the codebase as a
  whole, and check which kernel a given path actually selects (here a single
  environment variable chose between a 13 GB/s kernel and a 30 GB/s one).
- Final-size sanity checks in both directions: at T = 1 the payload sets a hard ceiling
  (`payload / bandwidth`), and at large T the compute does (`batch x MACs / rate`).
  Whichever is larger is where to spend the effort, and they are usually not the same
  resource.

---

## 13. Check the operand width before choosing an engine

When a quantised format is the whole point of the engine (2-bit ternary, 4-bit int,
fp8), the operand width is a **design constraint, not an implementation detail**:

- measure the achievable bytes per weight in the packed form, and the widest operand
  any candidate instruction requires;
- compute both ceiling terms before writing code: at T = 1 a wider operand can only
  lose, at large T it can only win;
- and remember that a *load* instruction can change the layout for free: many ISAs
  provide a load-and-transpose that pulls a 16x16 tile straight into matrix-core
  operand registers (on RDNA4: `GLOBAL_LOAD_TR_B64/B128`), which is what makes a
  hand-written matrix-core kernel viable at all.
- **Check whether the matrix core offers a mixed pair before assuming weight-only
  quantisation works.** On one target every matrix pair was same-type (wide/wide,
  8-bit/8-bit, narrow/narrow), so choosing a 4-bit *weight* operand forced a 4-bit
  *activation* operand too, which is a numerical change to everything the activations
  feed. On a different target the mixed narrow-weight/wide-activation pair existed. That
  single fact decides whether the quantised path can stay numerically transparent, so
  establish it before designing the kernel, not after.
- **Enumerate the datatype pairs the target actually exposes** from the vendor's
  kernel-template library. That table is the real menu, and it is frequently wider or
  narrower than the manual implies: it is where a 4-bit matrix path that the assembly
  generator does not cover for your target will show up, and where a pair that exists
  only on a later target family will be revealed as unavailable on yours.
- **A datatype in the generator's enum is not availability on your target.** One
  generator listed 4-bit float and a packed 4xint8 type, which reads at first glance as
  "4-bit is supported", but the 4-bit *float* matrix opcode was gated to a later target
  family and the 4-bit *integer* datatype did not exist at all, so for this target the
  answer was still no. Check the capability gate that the datatype is wired to, not the
  datatype's presence.

---

## 14. Get target facts from the vendor's source tree, not only the vendor's manual

Manuals and capability tables are the weakest sources; the compiler's own tests and the
vendor's tuned kernels are the strongest. Ranked by what actually settled questions:

1. **The compiler's test suite and intrinsic table.** A builtin's exact signature is stated
   in the compiler's generated builtin table and, better, exercised in a test that calls it.
   Here the manual implied one operand shape for the 4-bit matrix op; the compiler's own
   test showed the 16-deep form takes a **scalar** operand while the 32-deep form and the
   8-bit form take a **2-wide vector**, each with a leading sign flag and a trailing clamp
   flag. A probe compiled against the wrong shape reports the whole instruction family as
   unavailable, which is a false negative that costs days.
2. **The backend's code-generation tests.** These pin the emitted instruction and its
   register operands: the accumulator is always eight registers, and the operand width
   differs per variant (one register for the 16-deep 4-bit form, two for the 32-deep form
   and for the 8-bit form). That plus the modifier syntax is the difference between a
   kernel that encodes and one that silently computes nonsense.
3. **The vendor's own higher-level library wrappers.** The vendor's matrix-op header in its
   kernel library shows the call as the vendor writes it, including which sign flags are
   set for integer data and how the packed 4-bit type is bit-cast into the builtin.
4. **The vendor's tuned kernel definitions.** These are the only source that says which
   shapes actually win in practice. A census over the whole tuned set for the target told
   us that every tuned GEMM used the 16-deep matrix instruction with a 128x128 tile and a
   K depth of 32 or 64, and that the set contained **no 4-bit kernel at all**, so there was
   nothing to copy for this job. A census beats any single example.
5. **The tuned device code itself.** Modern ROCm ships per-architecture device code in
   packed archives that can be unpacked and disassembled. One real inner loop showed the
   operand marshalling (a byte-swizzle permute plus a half-word shared-memory load), the
   pipeline waits, and that the compiler emits dual-issued instruction pairs there. That is
   executable ground truth, and it is the same tier as the device artifact rule in
   section 7: the binary is the specification.
6. **The manual** for rules that no code states explicitly, such as the pipeline spacing
   between matrix ops and the load-with-transpose operations, while distrusting its tables.
   This one was mangled badly enough that a layout read straight from it would have been
   wrong.

Corollary: an instruction that a manual lists but a compiler rejects is usually a spelling
or signature problem, not a missing instruction. Check the compiler's table before
concluding that a feature is absent.

## 15. Tooling that enforces this

Available in this MCP:

| tool | use |
|---|---|
| `capability_report` | what this host can actually build for a target |
| `probe_isa` | compile candidates, one TU each, report encode + emitted ISA |
| `scan_residual_asm` | gate: no foreign mnemonic inside a live asm string |
| `build_module` | delete-then-build, report size + symbol inventory |
| `build_porting_map` | per-function construct/fidelity map derived from source |
| `lookup_construct` | one construct → target substitution + grade |
| `verify_porting_map` | probe every mapped replacement, fold results back |
| `code_object_report` | artifact truth: wave size, registers, spills, LDS per block, residency, instruction mix |
| `postport_recheck` | post-port safeguards from measurements: dispatch overhead share, dispatch count vs source, fusion legality, workgroup ceiling, utilisation, source parity, extension advertised/enabled/used |

Use them in that order: capability, probe, map, gate, build, run, recheck — and
re-run the recheck after every change, because the delta is the result.

## 16. Per-dispatch cost is a design parameter, not a constant

A Vulkan engine ported from AMD to Intel, same kernels, same quantisation:

| quantity | value |
|---|---|
| throughput on the source platform | 32-34 tok/s |
| throughput on the target | **20.65 tok/s** |
| dispatches per token | ~263 (116 of them GEMV) |
| measured cost of one dispatch on the target | ~385 us (AMD: ~100 us) |
| arithmetic the GPU actually needs per GEMV | ~15 us |
| overhead share of a 48.4 ms token | **92%** |
| utilisation of peak | **0.03%** |

Every number in that table says the same thing: the kernels were fine and the
*structure* was wrong for the target. The engine had been designed where a
dispatch cost 100 us and carried that shape to a driver where it cost 385 us.
No amount of inner-loop work recovers 44.7 ms of submit overhead.

The transferable rules, which is the point:

1. **Measure the dispatch cost before you optimise anything.** Time N trivial
   dispatches with the pipeline bound once. Do not take the number from a
   traced run: tracing inflates per-dispatch cost.
2. **Compute `overhead x dispatches` against iteration time.** Over half is a
   structural problem, not a kernel problem. Under a quarter is where
   micro-optimisation starts paying.
3. **Compare the dispatch count with the source platform.** A port that
   multiplies dispatches pays a cost the source never did, even at parity per
   dispatch.
4. **Fusion is legal only where the dependency is per-element or per-row.**

   | producer | consumer reads | fusable? |
   |---|---|---|
   | gate GEMV | up GEMV | per-element | yes |
   | gate+up | silu | per-element | yes |
   | silu | down GEMV | **all** silu values | no: needs a barrier = a new dispatch |
   | norm | gate GEMV | per-row | yes |
   | QKV | score | all Q and K | no |

   On a compute API with no device-wide barrier (Vulkan compute), the "no" rows
   are unavailable at any workgroup size. A shader that reads a whole producer
   output without one reads garbage.
5. **The workgroup ceiling is a measurement.** This driver was unstable above
   256; the fused shader shipped at 1024 and was 47% slower. Sweep the sizes
   with the real shader.
6. **Utilisation gives the diagnosis its scale.** 0.03% of peak is not a slow
   kernel, it is a starved one. Compare achieved against the spec peak for the
   datatype, not against the previous platform's absolute number.
7. **Extension available is not extension used.** Descriptor buffers, push
   descriptors, shader objects and timeline semaphores were all advertised;
   buffer device address was enabled and never used. Enabled-but-unused is a
   claim, not a speedup.
8. **Attribute a uniform slowdown correctly.** When every kernel is slower by
   the same proportion, the cost is between the kernels (dispatch, copy, sync),
   not inside one of them.

Barrier analysis for this port: what should have stopped it was a performance
model that carries per-dispatch cost. Existence: **no** (there was no such
model). Bypass: n/a — it was a design gap, not a skipped check. That gap is now
`postport_recheck`, and the pre-port rows `efficiency.dispatch_overhead`,
`structure.dispatch_count`, `structure.fusion_legality`,
`limits.workgroup_size`, `efficiency.peak_utilisation`,
`efficiency.source_parity` and `extensions.available_vs_used` put it in front of
every port of every backend.
